from django.contrib import admin
from django.urls import include, path, re_path
from django.http import HttpResponse, HttpResponseRedirect, Http404, FileResponse
from django.utils.html import format_html
from django.conf import settings

from threading import Thread
from .models import TPS
from .auxilliary import name_format, download_csv_file, convert
import os 

class TPSAdmin(admin.ModelAdmin):
    change_list_template = "change_list.html"
    list_display = ('name', 'url', 'last_modified', 'answers', 'action')

    def get_urls(self):
        urls = super().get_urls()
        my_urls = [
            path('update/', self.update),
            path('view/', self.view),
            re_path(r'^download/(?P<id>[\w-]+)/$', self.download),
        ]
        return my_urls + urls

    def action(self, request):
        return format_html(
            '<a class="button" href="download/{}">DOWNLOAD</a>'.format(request.id))
 
    def update(self, request):
        self.message_user(request, "TPS atualizados!")
        return HttpResponseRedirect("../")

    def view(self, request):
        self.message_user(request, "View called!")
        return HttpResponseRedirect("../")

    def download(self, request, id):
        fn, fdata = download_csv_file(id)
        fn = name_format(fn)    
        output = convert(fn, fdata)
        return FileResponse(open(output, 'rb'), as_attachment=True, filename=fn)

admin.site.register(TPS, TPSAdmin)
