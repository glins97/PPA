from django.apps import AppConfig


class DestratorConfig(AppConfig):
    name = 'destrator'
