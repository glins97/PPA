import datetime
import os, django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "services.settings")
django.setup()

from destrator.models import TPS, TPSAnswer
from destrator.aux import retrieve_drive_files, name_format

for f in retrieve_drive_files():
    print(f['title'])
    tps = TPS.objects.create(
        id=f['id'],
        name=name_format(f['title']),
        url=f['alternateLink'],
        last_modified=datetime.datetime.now(),
        answers=0
    )
    tps.save()
